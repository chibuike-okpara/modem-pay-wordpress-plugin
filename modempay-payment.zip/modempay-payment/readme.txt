=== Modem Pay Payment Form ===
Contributors: Caleb Chibuike
Tags: payment, ecommerce, modem pay, gambia, checkout, wordpress payments  
Requires at least: 5.0  
Tested up to: 6.8
Requires PHP: 7.2  
Stable tag: 1.0.0  
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-2.0.html  

Accept secure payments through Modem Pay directly on your WordPress site. Perfect for merchants in The Gambia and the region.

== Description ==

Modem Pay is a digital payment gateway tailored for the Gambian market. This plugin allows businesses to integrate Modem Pay into their WordPress websites to securely accept payments via mobile money (Qmoney, Afrimoney) and other supported channels.

**Key Features:**

* Create multiple payment forms with custom fields  
* Set redirect URLs after payment  
* Seamless integration with the Modem Pay API  
* Webhook support for real-time payment updates  
* Sandbox mode for safe testing  
* Secure and lightweight plugin  

Whether you're a school, small business, or large enterprise, Modem Pay makes it easy to accept payments without complex setup.

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory, or install the plugin via the WordPress dashboard by uploading the `.zip` file.  
2. Activate the plugin through the ‘Plugins’ menu in WordPress.  
3. Go to **Modem Pay Forms > Settings** and configure your API keys, webhook URLs, and other options.  
4. Create payment forms from the plugin menu and embed them on any page using shortcodes.

== Frequently Asked Questions ==

= Does this work outside The Gambia? =  
Currently, Modem Pay is optimized for Gambian merchants with support for Qmoney, Afrimoney, and more. International expansion is in progress.

= Can I test payments without going live? =  
Yes, a **sandbox mode** is included. Use your test API keys to simulate transactions.

= Does this support webhooks? =  
Yes, you can configure a webhook URL to receive real-time updates from Modem Pay.

== Screenshots ==

1. Settings panel for Modem Pay
2. Payment form on a WordPress page
3. Transaction success screen
4. Payment history (coming soon)

== Changelog ==

= 1.0.0 =  
* Initial release  
* Supports creating and embedding payment forms  
* Includes sandbox mode  
* Webhook support  
* Admin settings for API key and redirect URLs  

== Upgrade Notice ==

= 1.0.0 =  
First release of the official Modem Pay plugin for WordPress.

== License ==

This plugin is licensed under the GPLv2 or later.
