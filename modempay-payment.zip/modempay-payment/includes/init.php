<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
  exit;
}

function create_payment_pages()
{
  global $wpdb;

  // Define the table name
  $table_name = $wpdb->prefix . 'modem_pay_pages';
  $charset_collate = $wpdb->get_charset_collate();

  // Check if the table already exists
  if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
    // SQL to create the table
    $sql = "CREATE TABLE $table_name (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      title varchar(255) NOT NULL,
      redirect_url varchar(255) DEFAULT NULL,
      amount varchar(255) DEFAULT NULL,
      custom_fields text DEFAULT NULL,
      currency varchar(3) DEFAULT 'GMD',
      hide_title boolean DEFAULT FALSE,
      pay_button_text varchar(255) DEFAULT 'Pay',
      success_message text DEFAULT NULL,
      email_subject varchar(255) DEFAULT NULL,
      email_body text DEFAULT NULL,
      PRIMARY KEY (id)
  ) $charset_collate;";


    // Include the upgrade functions
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);  // dbDelta will handle table creation or update
  }
};



// Load settings page
require_once plugin_dir_path(__FILE__) . 'settings.php';
require_once plugin_dir_path(__FILE__) . 'shortcodes_reader.php';
require_once plugin_dir_path(__FILE__) . 'shortcodes.php';
require_once plugin_dir_path(__FILE__) . 'admin-payment-pages.php';
require_once plugin_dir_path(__FILE__) . 'admin-add-payment-page.php';
require_once plugin_dir_path(__FILE__) . 'admin-edit-payment-page.php';
require_once plugin_dir_path(__FILE__) . 'admin-delete-payment-page.php';
