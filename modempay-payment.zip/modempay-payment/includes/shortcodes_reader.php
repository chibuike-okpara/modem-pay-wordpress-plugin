<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
  exit;
}

// Shortcode handler for [text]
function custom_modem_pay_text_shortcode($atts)
{
  // Clean and sanitize the attributes
  $atts = shortcode_atts(array(
    'name' => '',
  ), $atts);

  // Clean the 'name' attribute to remove escape characters like \” and ensure no unwanted characters
  $name = stripslashes(sanitize_text_field($atts['name']));

  return '<div class="form_group_card form_group_half">
  <label for="custom_modem_pay_' . esc_attr($name) . '">' . esc_html($name) . ':</label>
            <input type="text" placeholder="' . esc_attr($name) . '" name="custom_modem_pay_' . esc_attr($name) . '" id="custom_modem_pay_' . esc_attr($name) . '" required>
            </div>';
}

add_shortcode('text', 'custom_modem_pay_text_shortcode');

// Shortcode handler for [textarea]
function custom_modem_pay_textarea_shortcode($atts)
{
  // Clean and sanitize the attributes
  $atts = shortcode_atts(array(
    'name' => '',
  ), $atts);

  // Clean the 'name' attribute to remove escape characters like \” and ensure no unwanted characters
  $name = stripslashes(sanitize_text_field($atts['name']));

  return '<div class="form_group_card form_group_half"><label for="custom_modem_pay_' . esc_attr($name) . '">' . esc_html($name) . ':</label>
            <textarea placeholder="' . esc_attr($name) . '" name="custom_modem_pay_' . esc_attr($name) . '" id="custom_modem_pay_' . esc_attr($name) . '" required></textarea></div>';
}

add_shortcode('textarea', 'custom_modem_pay_textarea_shortcode');

// Shortcode handler for [dropdown]
function custom_modem_pay_dropdown_shortcode($atts)
{
  // Clean and sanitize the attributes
  $atts = shortcode_atts(array(
    'name' => '',
    'options' => '',
  ), $atts);

  // Clean the 'name' and 'options' attributes to remove escape characters and sanitize
  $name = stripslashes(sanitize_text_field($atts['name']));
  $options = stripslashes(sanitize_text_field($atts['options']));

  $options_array = explode(',', $options);

  $dropdown = '<div class="form_group_card form_group_half"><label for="custom_modem_pay_' . esc_attr($name) . '">' . esc_html($name) . ':</label>
                 <select name="custom_modem_pay_' . esc_attr($name) . '" id="custom_modem_pay_' . esc_attr($name) . '" required>';
  foreach ($options_array as $option) {
    $dropdown .= '<option value="' . esc_attr($option) . '">' . esc_html($option) . '</option>';
  }
  $dropdown .= '</select></div>';
  return $dropdown;
}
add_shortcode('dropdown', 'custom_modem_pay_dropdown_shortcode');

// Shortcode handler for [radio]
function custom_modem_pay_radio_shortcode($atts)
{
  // Clean and sanitize the attributes
  $atts = shortcode_atts(array(
    'name' => '',
    'options' => '',
  ), $atts);

  // Clean the 'name' and 'options' attributes to remove escape characters and sanitize
  $name = stripslashes(sanitize_text_field($atts['name']));
  $options = stripslashes(sanitize_text_field($atts['options']));

  $options_array = explode(',', $options);

  $radio_buttons = '<div class="radio-container"><label class="radio-label">' . esc_html($name) . ':</label><div class="radio-holder">';
  foreach ($options_array as $option) {
    $radio_buttons .= '<div><label for="custom_modem_pay_' . esc_attr($option) . '"><input type="radio" id="custom_modem_pay_' . esc_attr($option) . '" name="custom_modem_pay_' . esc_attr($name) . '" value="' . esc_attr($option) . '">' . esc_html($option) . '</label></div>';
  }
  $radio_buttons .= '</div></div>';
  return $radio_buttons;
}
add_shortcode('radio', 'custom_modem_pay_radio_shortcode');

// Shortcode handler for [checkbox]
function custom_modem_pay_checkbox_shortcode($atts)
{
  // Clean and sanitize the attributes
  $atts = shortcode_atts(array(
    'name' => '',
    'options' => '',
  ), $atts);

  // Clean the 'name' and 'options' attributes to remove escape characters and sanitize
  $name = stripslashes(sanitize_text_field($atts['name']));
  $options = stripslashes(sanitize_text_field($atts['options']));

  $options_array = explode(',', $options);

  $checkboxes = '<div class="radio-container"><label class="radio-label">' . esc_html($name) . ':</label><div class="radio-holder">';
  foreach ($options_array as $option) {
    $checkboxes .= '<div><label for="custom_modem_pay_' . esc_attr($option) . '"><input type="checkbox" id="custom_modem_pay_' . esc_attr($option) . '" name="custom_modem_pay_' . esc_attr($name) . '[]" value="' . esc_attr($option) . '">' . esc_html($option) . '</label></div>';
  }
  $checkboxes .= '</div></div>';
  return $checkboxes;
}
add_shortcode('checkbox', 'custom_modem_pay_checkbox_shortcode');
