<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
  exit;
}

// Add a menu item for the settings page
function modem_pay_add_settings_menu()
{
  add_submenu_page(
    'Modem Pay Settings', // Page title
    'Settings', // Menu title
    'manage_options', // Capability
    'modem-pay-settings', // Menu slug
    'modem_pay_render_settings', // Callback function
    'dashicons-admin-generic', // Icon
    25 // Position
  );
}
// add_action('admin_menu', 'modem_pay_add_settings_menu');

// Render the settings page
function modem_pay_render_settings()
{
  // Handle form submission
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer('modem_pay_save_settings')) {
    update_option('modem_pay_public_api_key', sanitize_text_field($_POST['modem_pay_public_api_key']));
    update_option('modem_pay_send_emails', isset($_POST['modem_pay_send_emails']) ? 1 : 0);
    update_option('modem_pay_notification_email', sanitize_email($_POST['modem_pay_notification_email']));

    echo '<div class="notice notice-success is-dismissible"><p>Settings Saved</p></div>';
  }

  // Retrieve current settings
  $api_key = get_option('modem_pay_public_api_key', '');
  $send_emails = get_option('modem_pay_send_emails', 0);
  $notification_email = get_option('modem_pay_notification_email', '');

?>
  <div class="wrap">
    <h1>Modem Pay Settings</h1>
    <form method="post">
      <?php wp_nonce_field('modem_pay_save_settings'); ?>
      <table class="form-table">
        <tr>
          <th scope="row">
            <label for="modem_pay_public_api_key">Public API Key</label>
          </th>
          <td>
            <div style="display: flex; align-items: center;">
              <input name="modem_pay_public_api_key" id="modem_pay_public_api_key" type="password"
                value="<?php echo esc_attr($api_key); ?>" class="regular-text" style="margin-right: 10px;">
              <button type="button" class="button button-secondary" id="toggle_password_visibility">
                Show
              </button>
            </div>
          </td>
        </tr>
        <tr>
          <th scope="row">
            <label for="modem_pay_send_emails">Send Notification Emails</label>
          </th>
          <td>
            <input name="modem_pay_send_emails" id="modem_pay_send_emails" type="checkbox" value="1"
              <?php checked($send_emails, 1); ?>>
          </td>
        </tr>
        <tr>
          <th scope="row">
            <label for="modem_pay_notification_email">Notification Email</label>
          </th>
          <td>
            <input name="modem_pay_notification_email" id="modem_pay_notification_email" type="email"
              value="<?php echo esc_attr($notification_email); ?>" class="regular-text">
          </td>
        </tr>
      </table>
      <button type="submit" class="button button-primary">Save Changes</button>
    </form>
  </div>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const toggleButton = document.getElementById("toggle_password_visibility");
      const passwordInput = document.getElementById("modem_pay_public_api_key");

      toggleButton.addEventListener("click", function() {
        if (passwordInput.type === "password") {
          passwordInput.type = "text";
          toggleButton.textContent = "Hide";
        } else {
          passwordInput.type = "password";
          toggleButton.textContent = "Show";
        }
      });
    });
  </script>
<?php
}
