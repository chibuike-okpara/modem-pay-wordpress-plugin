<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
  exit;
}

// Shortcode handler for the payment page form
function modem_pay_payment_page_shortcode($atts)
{
  global $wpdb;

  // Get the page ID from the shortcode attributes
  $atts = shortcode_atts(array(
    'id' => '',  // The ID of the payment page to display
  ), $atts);

  $payment_page_id = intval($atts['id']);

  if ($payment_page_id <= 0) {
    return '<p>Invalid payment page ID.</p>';
  }

  // Retrieve the payment page data from the database
  $table_name = $wpdb->prefix . 'modem_pay_pages';
  $payment_page = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $payment_page_id));

  if (!$payment_page) {
    return '<p>Payment page not found.</p>';
  }

  // Start building the payment form
  ob_start();
?>
  <link rel="stylesheet" href="https://api.modempay.com/dist/main.css">
  <script src="https://api.modempay.com/js/v1.js"></script>
  <div class="container">
    <div class="pay-container">
      <?php if ($payment_page->hide_title != 1): ?>
        <h3 id="title"><?php echo esc_html($payment_page->title); ?></h3>
      <?php endif; ?>
      <p class="description">Complete the form below to proceed with your payment.</p>
      <?php if (!empty($payment_page->amount)): ?>
        <div class="amount" id="amount" data-amount="<?php echo $payment_page->amount; ?>">
        </div>
      <?php endif; ?>

      <form id="modem_pay_form_<?php echo esc_attr($payment_page->id); ?>" onsubmit="return initiatePayment(event)"
        class="modem_pay_form">

        <?php if (empty($payment_page->amount)): ?>
          <div class="form_group_card form_group_half">
            <label for="modem_pay_amount">Amount:</label>
            <input type="number" placeholder="Amount to pay" id="modem_pay_amount" name="modem_pay_amount" value="<?php echo esc_attr($payment_page->amount);
                                                                                                                  ?>"
              required>
          </div>
        <?php endif; ?>

        <div class="form_group_card form_group_half">
          <label for="modem_pay_fullname">Full name:</label>
          <input type="text" id="modem_pay_fullname" placeholder="Enter your full name" name="modem_pay_fullname"
            required>
        </div>

        <div class="form_group_card form_group_half">
          <label for="modem_pay_email">Email address:</label>
          <input type="email" id="modem_pay_email" placeholder="Enter your email address" name="modem_pay_email" required>
        </div>

        <div class="form_group_card form_group_half">
          <label for="modem_pay_phone">Phone number:</label>
          <input type="tel" id="modem_pay_phone" placeholder="Enter your phone number" name="modem_pay_phone"
            minlength="7" maxlength="7">
        </div>

        <!-- Custom fields section -->
        <?php if (!empty($payment_page->custom_fields)): ?>
          <!-- <div class="modem-pay-custom-fields"> -->
          <?php echo do_shortcode(stripslashes($payment_page->custom_fields)); ?>
          <!-- </div> -->
        <?php endif; ?>

        <div class="form_group_card">
          <input type="hidden" id="action" name="action" value="process_payment_via_modem_pay">
          <input type="hidden" id="modem_pay_public_api_key" name="modem_pay_public_api_key"
            value="<?php echo get_option('modem_pay_public_api_key', '') ?>">
          <input type="hidden" id="payment_page_id" name="payment_page_id"
            value="<?php echo esc_attr($payment_page->id); ?>">
          <input type="hidden" id="return_url" name="return_url"
            value="<?php echo esc_attr($payment_page->redirect_url); ?>">
          <input type="hidden" name="success_message" id="success_message"
            value="<?php echo esc_attr($payment_page->success_message); ?>">
        </div>

        <div class="form_group_card div-center">
          <button type="submit"
            class="submit-button"><?php echo $payment_page->pay_button_text ?? "Proceed to Payment" ?></button>
        </div>
      </form>
    </div>
  </div>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const amountElement = document.getElementById('amount');
      if (amountElement) {
        const amount = parseFloat(amountElement.getAttribute('data-amount'));
        if (!isNaN(amount)) {
          const formattedAmount = new Intl.NumberFormat('en-GB', {
            style: 'currency',
            currency: 'GMD',
          }).format(amount);

          // Set the formatted amount inside the div
          amountElement.textContent = formattedAmount;
        }
      }
    });
  </script>
  <script>
    function initiatePayment(event) {
      event.preventDefault(); // Prevent form submission

      try {
        // Retrieve form values
        const amount = document.getElementById('modem_pay_amount')?.value || document.getElementById('amount')?.dataset
          .amount;
        const fullname = document.getElementById('modem_pay_fullname').value;
        const phone = document.getElementById('modem_pay_phone').value;
        const email = document.getElementById('modem_pay_email').value;
        const paymentPageId = document.getElementById('payment_page_id').value;
        const action = document.getElementById('action').value;
        const public_key = document.getElementById('modem_pay_public_api_key').value
        const title = document.getElementById('title')?.innerText ?? null;
        const return_url = document.getElementById('return_url')?.value ?? null;
        const success_message = document.getElementById('success_message').value ?? null;

        // Retrieve all custom fields
        const customFields = {};
        const form = event.target; // The form element
        const inputs = form.querySelectorAll(
          '[name^="custom_modem_pay_"]'); // Select fields with names starting with "custom_modem_pay_"

        inputs.forEach(input => {
          const name = input.name.replace('custom_modem_pay_', ''); // Strip prefix for cleaner keys
          if (input.type === 'checkbox') {
            // Handle checkboxes (array values)
            if (!customFields[name]) customFields[name] = [];
            if (input.checked) customFields[name].push(input.value);
          } else if (input.type === 'radio') {
            // Handle radio buttons
            if (input.checked) customFields[name] = input.value;
          } else {
            // Handle other inputs (text, textarea, dropdown)
            customFields[name] = input.value;
          }
        });

        const modal = ModemPayCheckout({
          amount,
          public_key,
          payment_methods: "wallet",
          title,
          currency: "GMD",
          customer_phone: phone,
          customer_email: email,
          customer_name: fullname,
          metadata: {
            wp_modem_pay_payment_page_id: paymentPageId,
            action,
          },
          custom_fields_values: customFields,
          success_message,
          return_url,
          callback: (transaction) => {
            setTimeout(() => {
              modal.close();
            }, 5000);
          },
          onClose: (cancelled) => {
            if (!cancelled) {
              window.location.reload()
            }
          }
        })
      } catch (error) {
        console.error(error.message);

      }

    }
  </script>

<?php

  // Return the form output
  return ob_get_clean();
}

add_shortcode('modem_pay_payment_page', 'modem_pay_payment_page_shortcode');
