<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
  exit;
}

// Render the "Edit Payment Page" form
function modem_pay_render_edit_payment_page()
{

  if (isset($_GET['id'])) {
    $page_id = intval($_GET['id']);
  }

  global $wpdb;
  $table_name = $wpdb->prefix . 'modem_pay_pages';
  $page = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $page_id));

  if (!$page) {
    echo '<div class="notice notice-error"><p>Payment page not found.</p></div>';
    return;
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['modem_pay_update_page'])) {
    $title = sanitize_text_field($_POST['modem_pay_title']);
    $redirect_url = isset($_POST['modem_pay_redirect_url']) ? esc_url_raw($_POST['modem_pay_redirect_url']) : '';
    $amount = isset($_POST['modem_pay_amount']) ? sanitize_text_field($_POST['modem_pay_amount']) : '';
    $custom_fields = isset($_POST['modem_pay_custom_fields']) ? sanitize_textarea_field($_POST['modem_pay_custom_fields']) : '';
    $currency = isset($_POST['modem_pay_currency']) ? sanitize_text_field($_POST['modem_pay_currency']) : 'GMD';
    $hide_title = isset($_POST['modem_pay_hide_title']) ? (bool) $_POST['modem_pay_hide_title'] : false;
    $pay_button_text = isset($_POST['modem_pay_pay_button_text']) ? sanitize_text_field($_POST['modem_pay_pay_button_text']) : 'Pay';
    $success_message = isset($_POST['modem_pay_success_message']) ? sanitize_textarea_field($_POST['modem_pay_success_message']) : '';
    $email_subject = isset($_POST['modem_pay_email_subject']) ? sanitize_text_field($_POST['modem_pay_email_subject']) : '';
    $email_body = isset($_POST['modem_pay_email_body']) ? sanitize_textarea_field($_POST['modem_pay_email_body']) : '';

    $wpdb->update($table_name, [
      'title' => $title,
      'redirect_url' => $redirect_url,
      'amount' => $amount,
      'custom_fields' => str_replace('\\', '', $custom_fields),
      'currency' => $currency,
      'hide_title' => $hide_title,
      'pay_button_text' => $pay_button_text,
      'success_message' => $success_message,
      'email_subject' => $email_subject,
      'email_body' => $email_body,
    ], ['id' => $page_id]);

    echo '<div class="notice notice-success is-dismissible"><p>Payment page updated successfully.</p></div>';
    echo '<script>window.location.href = "' . admin_url('admin.php?page=modem-pay-payment-pages') . '";</script>';
    exit;
  }
?>

  <form method="post" class="wrap" autocomplete="off">
    <h1>Edit Payment Form</h1>

    <div style="display: flex; gap: 20px;">
      <!-- Left Column -->
      <div style="flex: 3;">

        <!-- Title Field -->
        <div class="postbox">
          <h2 class="hndle" style="padding-left: 15px; font-size: 15px;"><span>Form Title</span></h2>
          <div class="inside">
            <input type="text" name="modem_pay_title" id="modem_pay_title" class="large-text"
              value="<?php echo esc_attr($page->title); ?>" required>
          </div>
        </div>

        <!-- Shortcode Section -->
        <div class="postbox">
          <h2 class="hndle" style="padding-left: 13px; font-size: 15px;"><span>Edit Shortcodes</span></h2>
          <div class="inside">
            <button class="button button-secondary" onclick="insertShortcode(event, 'text')">Insert Text</button>
            <button class="button button-secondary" onclick="insertShortcode(event, 'textarea')">Insert Textarea</button>
            <button class="button button-secondary" onclick="insertShortcode(event, 'dropdown')">Insert Dropdown</button>
            <button class="button button-secondary" onclick="insertShortcode(event, 'radio')">Insert Radio
              Options</button>
            <button class="button button-secondary" onclick="insertShortcode(event, 'checkbox')">Insert Checkbox
              Options</button>
            <br />
            <br />
            <textarea id="modem_pay_custom_fields" name="modem_pay_custom_fields" rows="5"
              class="large-text"><?php echo str_replace('\\', '', esc_attr($page->custom_fields)); ?></textarea>
            <p class="description">Modify shortcodes like [text name='Field Name'] or [dropdown name='Field Name'
              options='Option 1, Option 2']</p>
          </div>
        </div>

        <!-- Extra Form Settings -->
        <div class="postbox">
          <h2 class="hndle" style="padding-left: 13px; font-size: 15px;"><span>Extra Form Settings</span></h2>
          <div class="inside">
            <label><input type="checkbox" id="modem_pay_hide_title" name="modem_pay_hide_title"
                value="<?php echo esc_attr($page->hide_title); ?>">
              Hide the form title</label><br>
            <p><strong>Currency:</strong></p>
            <select id="modem_pay_currency" name="modem_pay_currency">
              <option value="<?php echo esc_attr($page->currency); ?>">Gambian Dalasis</option>
            </select>
            <p><strong>Amount:</strong></p>
            <input type="number" name="modem_pay_amount" id="modem_pay_amount" class="large-text"
              value="<?php echo esc_attr($page->amount); ?>">
            <p><strong>Pay Button Description:</strong></p>
            <input type="text" id="modem_pay_pay_button_text" name="modem_pay_pay_button_text" class="large-text"
              value="<?php echo esc_attr($page->pay_button_text); ?>">
            <p><strong>Success Message:</strong></p>
            <textarea id="modem_pay_success_message" name="modem_pay_success_message" rows="3"
              class="large-text"><?php echo esc_attr($page->success_message); ?></textarea>
            <p><strong>Redirect URL:</strong></p>
            <input type="url" id="modem_pay_redirect_url" name="modem_pay_redirect_url" class="large-text"
              value="<?php echo esc_attr($page->redirect_url); ?>">
          </div>
        </div>

        <!-- Email Receipt Settings -->
        <div class="postbox">
          <h2 class="hndle" style="padding-left: 13px; font-size: 15px;"><span>Email Receipt Settings</span></h2>
          <div class="inside">
            <label for="email_subject">Email Subject:</label><br />
            <input type="text" id="modem_pay_email_subject" name="modem_pay_email_subject" class="large-text"
              value="<?php echo esc_attr($page->email_subject); ?>"><br /><br />
            <label for="email_body">Email Body/Message:</label><br />
            <textarea id="modem_pay_email_body" name="modem_pay_email_body" rows="5"
              class="large-text"><?php echo esc_attr($page->email_body); ?></textarea>
          </div>
        </div>
      </div>

      <!-- Right Sidebar -->
      <div style="flex: 1;">
        <div class="postbox">
          <h2 class="hndle" style="padding-left: 13px; font-size: 15px;"><span>Update</span></h2>
          <div class="inside">
            <button class="button button-primary" name="modem_pay_update_page" type="submit">Update Form</button>
          </div>
        </div>
      </div>
    </div>
  </form>


  <script>
    function insertShortcode(event, fieldType) {
      event.preventDefault(); // Prevent the default action of the event

      let shortcode = '';
      let nameField = prompt("Enter the field name:");

      if (!nameField) return; // If no name is entered, do nothing

      switch (fieldType) {
        case 'text':
          shortcode = '[text name="' + nameField + '"]';
          break;
        case 'textarea':
          shortcode = '[textarea name="' + nameField + '"]';
          break;
        case 'dropdown':
          let options = prompt("Enter options separated by commas (e.g., 'Option 1, Option 2'):");
          if (options) {
            shortcode = '[dropdown name="' + nameField + '" options="' + options + '"]';
          }
          break;
        case 'radio':
          let radioOptions = prompt("Enter options separated by commas (e.g., 'Option 1, Option 2'):");
          if (radioOptions) {
            shortcode = '[radio name="' + nameField + '" options="' + radioOptions + '"]';
          }
          break;
        case 'checkbox':
          let checkboxOptions = prompt("Enter options separated by commas (e.g., 'Option 1, Option 2'):");
          if (checkboxOptions) {
            shortcode = '[checkbox name="' + nameField + '" options="' + checkboxOptions + '"]';
          }
          break;
      }

      // Insert the shortcode into the textarea
      const textarea = document.getElementById('modem_pay_custom_fields');
      textarea.value += shortcode;
      textarea.focus();
    }
  </script>

<?php
}
