<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
  exit;
}

// Render the payment pages list
function modem_pay_render_payment_pages_list()
{
  global $wpdb;

  // Fetch payment pages
  $table_name = $wpdb->prefix . 'modem_pay_pages';
  $payment_pages = $wpdb->get_results("SELECT * FROM $table_name");

?>
  <div class="wrap">
    <h1>Payment Pages</h1>
    <a href="<?php echo admin_url('admin.php?page=modem-pay-add-payment-page'); ?>" class="button button-primary">Add New
      Payment Page</a>
    <br />
    <br />
    <table class="wp-list-table widefat fixed striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Title</th>
          <th>Redirect URL</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($payment_pages) : ?>
          <?php foreach ($payment_pages as $page) : ?>
            <tr>
              <td><?php echo esc_html($page->id); ?></td>
              <td><?php echo esc_html($page->title); ?></td>
              <td><?php echo esc_html($page->redirect_url); ?></td>
              <td>
                <a href="<?php echo admin_url('admin.php?page=modem-pay-edit-payment-page&id=' . $page->id); ?>"
                  class="button">Edit</a>
                <a href="<?php echo wp_nonce_url(
                            admin_url('admin.php?page=modem-pay-delete-payment-page&id=' . $page->id),
                            'modem_pay_delete_' . $page->id
                          ); ?>" class="button">Delete</a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else : ?>
          <tr>
            <td colspan="4" class="manage-column column-primary" style="text-align: center;">
              No payment pages found.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php
}
