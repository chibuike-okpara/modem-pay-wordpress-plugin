<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
  exit;
}

if (!function_exists('wp_verify_nonce')) {
  require_once ABSPATH . 'wp-includes/pluggable.php';
}

// Check if ID and nonce are set in the URL
if (isset($_GET['id']) && isset($_GET['_wpnonce'])) {
  $id = intval($_GET['id']);

  // Verify nonce for security
  if (!wp_verify_nonce($_GET['_wpnonce'], 'modem_pay_delete_' . $id)) {
    wp_die('Security check failed');
  }

  // Check if user has permission to delete
  if (current_user_can('manage_options')) {
    // Handle confirmation process
    if (isset($_GET['confirm_delete']) && $_GET['confirm_delete'] === 'true') {
      // Proceed with deletion
      global $wpdb;
      $wpdb->delete("{$wpdb->prefix}modem_pay_pages", ['id' => $id]);

      // Redirect after deletion
      wp_redirect(admin_url('admin.php?page=modem-pay-payment-pages&deleted=1'));
      exit;
    } else {
      // Check for edge case: redirect back to avoid infinite loop
      if (isset($_SESSION['delete_confirmation']) && $_SESSION['delete_confirmation'] === $id) {
        // If user has already seen the confirmation, prevent them from being stuck
        wp_redirect(admin_url('admin.php?page=modem-pay-payment-pages'));
        exit;
      }

      // Set session for confirmation to prevent infinite loop
      $_SESSION['delete_confirmation'] = $id;

      // Display confirmation prompt
      echo '<div class="notice notice-warning is-dismissible" style="background-color: #ffeb3b; padding: 15px; border-radius: 5px; border: 1px solid #fbc02d; font-size: 16px; color: #333; margin-bottom: 20px;">';
      echo '<p style="margin: 0; font-weight: bold;">Are you sure you want to delete this page?</p>';
      echo '<p style="margin-top: 5px;">This action cannot be undone. <a href="' . esc_url(admin_url('admin.php?page=modem-pay-payment-pages&id=' . $id . '&_wpnonce=' . $_GET['_wpnonce'] . '&confirm_delete=true')) . '" style="color: #d32f2f; font-weight: bold;">Yes, delete it</a> | <a href="' . esc_url(admin_url('admin.php?page=modem-pay-payment-pages')) . '" style="color: #0073aa;">No, take me back</a></p>';
      echo '</div>';
      exit;
    }
  } else {
    wp_die('You do not have permission to perform this action.');
  }
}
