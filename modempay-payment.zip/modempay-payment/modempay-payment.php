<?php

/**
 * Plugin Name:       Modem Pay Payment Form
 * Description:       Secure payment processing for WordPress with Modem Pay. Accept credit cards, digital wallets, and alternative payment methods with customizable forms.
 * Version:           1.0.0
 * Requires at least: 5.6
 * Requires PHP:      7.4
 * Author:            Caleb Okpara
 * Author URI:        https://modempay.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

// Security check to prevent direct access
defined('ABSPATH') || exit;

// Define plugin constants
define('MODEMPAY_VERSION', '1.0.0');
define('MODEMPAY_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MODEMPAY_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MODEMPAY_PLUGIN_BASENAME', plugin_basename(__FILE__));


function modem_pay_enqueue_styles()
{
  // Enqueue the custom CSS file from the 'assets/css' folder
  wp_enqueue_style('modem-pay-styles', plugin_dir_url(__FILE__) . 'assets/modem-pay.css');
}

add_action('wp_enqueue_scripts', 'modem_pay_enqueue_styles');

// Include core plugin files
require_once plugin_dir_path(__FILE__) . 'includes/init.php';

register_activation_hook(__FILE__, function () {
  create_payment_pages();
  add_option('modem_pay_public_api_key', '');
  add_option('modem_pay_send_emails', 0);
  add_option('modem_pay_notification_email', '');
});

// Register the "Payment Pages" menu in WordPress admin
function modem_pay_add_payment_pages_menu()
{

  add_menu_page(
    'Payment Pages', // Page title
    'Modem Pay Forms', // Menu title
    'manage_options', // Capability
    'modem-pay-payment-pages', // Menu slug
    'modem_pay_render_payment_pages_list', // Callback function
    'dashicons-admin-generic', // Icon
    1 // Position
  );

  add_submenu_page(
    'modem-pay-payment-pages',
    'Add Payment Page',
    'Add New Page',
    'manage_options',
    'modem-pay-add-payment-page',
    'modem_pay_render_add_payment_page'
  );

  add_submenu_page(
    'modem-pay-payment-pages', // Page title
    'Modem Pay Settings', // Menu title
    'Settings', // Capability
    'manage_options', // Menu slug
    'modem_pay_render_settings',
    'modem_pay_render_settings'
  );
}

function modem_pay_register_edit_payment_page()
{
  add_submenu_page(
    null, // No parent menu (this page is accessed via direct URL)
    'Edit Payment Page',
    'Edit Payment Page',
    'manage_options',
    'modem-pay-edit-payment-page',
    'modem_pay_render_edit_payment_page'
  );
}

add_action('admin_menu', 'modem_pay_register_edit_payment_page');
add_action('admin_menu', 'modem_pay_add_payment_pages_menu');
